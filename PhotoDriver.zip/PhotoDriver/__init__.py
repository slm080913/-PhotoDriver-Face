import bpy
from .driver_photo import file_path,PHOTO_PRESET_FILE
from .driver_photo import FileUIList,FileItem,PhotoDriverFace,BasicPanel,AdvancedPanel,OtherPanel,PhotoIdentify,ReturnFolders,AddFolders
from .driver_photo import AddConstraints,RemoveDriver,AddDriver,ImportPhoto,PhotoTaken,FileDelete,AdjustPosition,LoadFolders,OpenFiles
from .photo_rig import RigShapeKey,AddPropertyDriver,RemoveProperties,RemovePropertyDriver,AddFrameToProperties,ReturnZero

bl_info = {
    "name": "PhotoDriver-Face",
    "author": "slm080913",
    "version": (1 , 0),
    "blender": (3, 6, 12),
    "location": "View3D > Sidebar > PhotoDriverFace",
    "description": "使用图片控制面部和形态键绑定\n,使用控制面部的骨骼属性和形态键绑定以创建姿态库",
    "category": "Animation",
    "tracker_url": "https://space.bilibili.com/641842593",
}


_addon_properties = {
    bpy.types.Scene: {
        # "face": bpy.props.PointerProperty(name="placeholder", type=bpy.types.Object, description="形态键物体"),
        "face_collection" : bpy.props.PointerProperty(name= "形态键物体集合" , type=bpy.types.Collection,
                                                      description= "要点击 要绑定物体集合"),
        "control_collection": bpy.props.PointerProperty(name="控制器集合", type=bpy.types.Collection,
                                                        description="控制器名称中有brow,eyes,mouth"),
        "photo_all_collection": bpy.props.PointerProperty(name="图片总集合", type=bpy.types.Collection,
                                                          description="其中要有子集brow,eyes,mouth"),
        "photo_all_bool" : bpy.props.BoolProperty(name="绑定面部表情",default=True),

        "wide" : bpy.props.FloatProperty(name= "照片总宽度",default= 8.0, min= 1.0, description= "图片面板的总宽度"),

        "file_list" : bpy.props.CollectionProperty(type=FileItem),
        "file_list_index" : bpy.props.IntProperty(name=f'可以在{file_path}文件夹中更改blender图片预设', default=0),
        "file_type" : bpy.props.BoolProperty(name="目录",default=False),

        "preset_name": bpy.props.StringProperty(name="文件名称", description=f"{file_path}中找到"),
        "select_type": bpy.props.EnumProperty(
            name="选择类型", items=[("brow", "brow", ""), ("eyes", "eyes", ""), ("mouth", "mouth", ""),("other","other","")],
            default="brow"),
        "first_name": bpy.props.StringProperty(name="初始", description="初始形态键的名字"),
        "last_name": bpy.props.StringProperty(name="结束", description="最后形态键的名字"),
        # # },
        # # bpy.types.IntProperty : {
        'brow_constraints_value': bpy.props.IntVectorProperty(name="brow约束位置", min=0, size=2),
        'eyes_constraints_value': bpy.props.IntVectorProperty(name="eyes约束位置", min=0, size=2),
        'mouth_constraints_value': bpy.props.IntVectorProperty(name="mouth约束位置", min=0, size=2),

        "rig_driver_bool" : bpy.props.BoolProperty(name="自定义属性绑定"),
        "control_armature" : bpy.props.PointerProperty(type=bpy.types.Object,name="控制器骨架"),
        "control_bone_name" : bpy.props.StringProperty(name= "控制器骨骼"),

        "control_step" : bpy.props.IntProperty(name="控制器步长",default=2),
    }
}


def _add_properties():
    for cls, properties in _addon_properties.items():
        for name, prop in properties.items():
            setattr(cls, name, prop)


def _remove_properties():
    for cls, properties in _addon_properties.items():
        for name in properties.keys():
            if hasattr(cls, name):
                delattr(cls, name)


_class_operator = [FileUIList,FileItem,PhotoDriverFace,BasicPanel,AdvancedPanel,
                   OtherPanel,AddConstraints,RemoveDriver,AddDriver,ImportPhoto,
                   PhotoTaken,FileDelete,AdjustPosition,PhotoIdentify,LoadFolders,
                   OpenFiles,ReturnFolders,AddFolders,
                   RigShapeKey,AddPropertyDriver,RemoveProperties,
                   RemovePropertyDriver,AddFrameToProperties,ReturnZero]


def _class_register():
    for cls in _class_operator:
        bpy.utils.register_class(cls)


def _class_unregister():
    for cls in _class_operator:
        bpy.utils.unregister_class(cls)


def register():
    _class_register()
    _add_properties()


def unregister():
    _class_unregister()
    _remove_properties()


if __name__ == "__main__":
    register()
