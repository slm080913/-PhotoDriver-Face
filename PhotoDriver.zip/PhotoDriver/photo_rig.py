import bpy

class RigShapeKey(bpy.types.Panel):
    bl_label = "自定义属性资产"
    bl_idname = "VIEW3D_PT_RigShapeKey"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Item"
    bl_order = 1

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        layout.label(text="自定义属性资产创建",icon="OBJECT_DATAMODE")
        layout.prop(scene,"face_collection")
        layout.prop(scene, "control_armature")

        control_armature = context.scene.control_armature
        control_armature : bpy.types.Object

        if control_armature is not None and control_armature.type == 'ARMATURE':
            self._bone_search(layout, scene, control_armature)

        layout.operator(AddPropertyDriver.bl_idname,icon="DRIVER_TRANSFORM")

        column = layout.column_flow(columns=2)
        column.operator(RemoveProperties.bl_idname,icon="PANEL_CLOSE")
        column.operator(RemovePropertyDriver.bl_idname, icon='TRASH')

        layout.separator()

        box = layout.box()
        box.label(text="骨骼属性资产管理",icon='MESH_ICOSPHERE')
        box.operator(AddFrameToProperties.bl_idname, icon="KEYTYPE_KEYFRAME_VEC")
        box.operator(ReturnZero.bl_idname, icon='ANIM')
        
        # box = layout.box()
        # box.prop(scene,"asset_library_path")
        # box.prop(scene, "asset_category_name")
        # box.operator(AddPropertyLibraries.bl_idname,icon="FILE_HIDDEN")
        # box.label(text="要选好资产库位置",icon="FILEBROWSER")

    def _bone_search(self, layout: bpy.types.UILayout, scene: bpy.types.Scene, armature_ob: bpy.types.Object) -> None:
        """Search within the bones of the given armature."""
        assert armature_ob and armature_ob.type == 'ARMATURE'

        layout.prop_search(
            scene,
            "control_bone_name",
            armature_ob.data,
            "edit_bones" if armature_ob.mode == 'EDIT' else "bones",
        )


class AddPropertyDriver(bpy.types.Operator):
    bl_idname = 'object.add_driver_rig'
    bl_label = '添加驱动器'
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = "原理是添加同名骨骼属性与同名形态键绑定"

    @classmethod
    def poll(cls, context: bpy.types.Context):
        return context.scene.face_collection and context.scene.control_armature is not None

    def execute(self, context):

        shape_key_collection = list(context.scene.face_collection.objects)

        control_bone_name =  context.scene.control_bone_name
        control_bone_name : str

        control_armature = context.scene.control_armature
        control_armature : bpy.types.Object

        # control_bone = control_armature.pose.bones[control_bone_name]


        def add_driver_single_prop(driver_object, target_object, bone_name, path, index, var_name, expression, data_path):

            #防止重复
            driver_object.driver_remove(path, index)

            driver = driver_object.driver_add(path, index).driver
            driver.type = 'SCRIPTED'  # string

            # 设置表达式
            driver.expression = expression
            driver.use_self = False  # 取消勾选“使用自身”

            # 添加输入变量
            var = driver.variables.new()
            var.name = var_name  # 变量名称
            var.type = 'SINGLE_PROP'  # 变量类型设置
            var.targets[0].id = target_object  # 目标物体
            if bone_name != "":
                var.targets[0].bone_target = bone_name
            var.targets[0].data_path = data_path

        def add_custom_property_to_bone(armature, bone_name, prop_name):

            if armature.type == 'ARMATURE':
            # 获取骨骼
                obj = armature.pose.bones[bone_name]
            else:
                obj = armature
            # 添加自定义属性
            obj[prop_name] = 0.0

            # 设置属性的最小值和最大值
            rna_ui = obj.id_properties_ui(prop_name)
            rna_ui.update(min=0.0, max=1.0)

        def rig_driver(pattern:bool):
            n = 0
            for face in shape_key_collection:
                # 获取绑定face物体的形态键collection
                try:
                    for shape_key in list(face.data.shape_keys.key_blocks):
                        n += 1
                        #防止base_shape_key
                        if n == 1 :
                            continue
                        #添加属性
                        if control_armature.type == 'ARMATURE':
                            # control_bone[shape_key.name] = 0
                            if pattern:
                                add_custom_property_to_bone(control_armature,control_bone_name,shape_key.name)
                                # 同名属性判断
                            else:
                                add_driver_single_prop(shape_key,control_armature,control_bone_name,
                                               "value",-1,"var","var",
                                               f'pose.bones["{control_bone_name}"]["{shape_key.name}"]')
                        else:
                            if pattern:
                                add_custom_property_to_bone(control_armature,control_bone_name,shape_key.name)
                            else:
                                add_driver_single_prop(shape_key,control_armature,
                                                   "","value",-1,"var","var"
                                                   ,f'["{shape_key.name}"]')
                except AttributeError:
                    self.report({'WARNING'}, "物体没有形态键")
                    return {'FINISHED'}

        rig_driver(True)
        rig_driver(False)

        self.report({'INFO'},"成功添加驱动器")
        return {'FINISHED'}


class RemoveProperties(bpy.types.Operator):
    bl_idname = 'object.remove_properties_rig'
    bl_label = '删除属性'
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = "删除骨骼所有自定义属性"

    @classmethod
    def poll(cls, context):
        return context.scene.face_collection is not None

    def execute(self, context):

        bpy.ops.object.remove_driver_bone()

        control_bone_name = context.scene.control_bone_name
        control_bone_name: str

        control_armature = context.scene.control_armature
        control_armature: bpy.types.Object

        def remove_custom_property_from_bone(armature, bone_name):

            if armature.type == 'ARMATURE':
                # 获取骨骼
                obj = armature.pose.bones[bone_name]
            else:
                obj = armature
            # 添加自定义属性

            # 检查属性是否存在
            for key in list(obj.keys()):
                if not key.startswith("_"):  # 忽略内置属性（以 "_" 开头）
                    del obj[key]

        remove_custom_property_from_bone(control_armature,control_bone_name)

        self.report({'INFO'},"成功删除属性")
        return {'FINISHED'}


class RemovePropertyDriver(bpy.types.Operator):
    bl_label = '删除驱动器'
    bl_idname = 'object.remove_driver_bone'
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = '要点击 形态键物体集合'

    @classmethod
    def poll(cls, context: bpy.types.Context):
        return context.scene.face_collection is not None

    def execute(self, context: bpy.types.Context):

        face_collection = list(context.scene.face_collection.objects)
        for face in face_collection:
            for key in list(face.data.shape_keys.key_blocks):
                key.driver_remove('value', -1)

        self.report({'INFO'}, "成功删除驱动器")
        return {'FINISHED'}


class AddFrameToProperties(bpy.types.Operator):
    bl_idname = "scene.add_frame_to_all_properties"
    bl_label = '添加全部关键帧'
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):

        scene = context.scene
        if scene.control_armature is not None:
            if scene.control_armature.type == 'ARMATURE':
                if scene.control_bone_name != "":
                    return True
                else:
                    return False
            else:
                return True

    def execute(self, context):

        control_bone_name = context.scene.control_bone_name

        control_armature = context.scene.control_armature
        control_armature: bpy.types.Object

        # asset_category_name = context.scene.asset_category_name
        # asset_category_name : str

        # control_bone = control_armature.pose.bones[control_bone_name]

        if control_armature.type == 'ARMATURE':
            # 获取骨骼
            control_obj = control_armature.pose.bones[control_bone_name]
        else:
            control_obj = control_armature


        def add_keyframe_to_bone_property(armature, bone_name, prop_name, frame):
            """
            为骨骼的属性添加关键帧
            :param armature: 骨架
            :param bone_name: 骨骼名称
            :param prop_name: 属性名称（如 'location', 'rotation_euler', 'scale' 或自定义属性名称）
            :param frame: 关键帧的帧数

            """
            # # 获取骨架对象
            # armature = bpy.data.objects[armature_name]

            if armature.type == 'ARMATURE':
                pose_bone = armature.pose.bones[bone_name]
            else:
                pose_bone = armature
            # if prop_name != 'mmd_bone':
            #     return
            # # 设置属性值
            # if prop_name in pose_bone.keys():  # 如果是自定义属性
            #     pose_bone[prop_name] = value
            # else:  # 如果是内置属性（如 location, rotation_euler 等）
            #     setattr(pose_bone, prop_name, value)

            # 插入关键帧
            pose_bone.keyframe_insert(data_path=f'["{prop_name}"]' if prop_name in pose_bone.keys() else prop_name,
                                      frame=frame)


        frame_current = context.scene.frame_current
        for key in list(control_obj.keys()):
            try:
                add_keyframe_to_bone_property(control_armature,control_bone_name,key,frame_current)
            except TypeError:
                pass
        self.report({'INFO'},"成功添加所有属性的全部关键帧")
        return {'FINISHED'}


class ReturnZero(bpy.types.Operator):
    bl_idname = "scene.properties_equal_zero"
    bl_label = '所有属性归零'
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):

        scene = context.scene
        if scene.control_armature is not None:
            if scene.control_armature.type == 'ARMATURE':
                if scene.control_bone_name != "":
                    return True
                else:
                    return False
            else:
                return True
        else:
            return False

    def execute(self, context):

        control_bone_name = context.scene.control_bone_name

        control_armature = context.scene.control_armature
        control_armature: bpy.types.Object

        if control_armature is None:
            self.report({'INFO'}, "控制骨架未设置")

        if control_armature.type == 'ARMATURE':
            # 检查骨骼是否存在
            if control_bone_name not in control_armature.pose.bones:
                self.report({'INFO'}, f"骨骼 '{control_bone_name}' 不存在于骨架中")

            control_obj = control_armature.pose.bones[control_bone_name]
        else:
            control_obj = control_armature

        # 设置属性值
        for prop_name in list(control_obj.keys()):  # 如果是自定义属性
            prop_value = control_obj[prop_name]
            if isinstance(prop_value, float) or isinstance(prop_value, int):
                control_obj[prop_name] = 0.0  # 直接修改属性值

        self.report({'INFO'}, "成功归零")
        return {'FINISHED'}

