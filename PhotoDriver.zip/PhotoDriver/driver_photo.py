import os
import shutil
from pathlib import Path
import bpy

PHOTO_PRESET_FILE = os.path.join(os.path.dirname(__file__), "PhotoPreset")
file_path = PHOTO_PRESET_FILE

class FileItem(bpy.types.PropertyGroup):
    name = bpy.props.StringProperty(name="Folder Name", default="Untitled")
FileItem : bpy.types.PropertyGroup


class FileUIList(bpy.types.UIList):
    bl_idname = "FILE_UL_List"

    def draw_item(
        self,
        context,
        layout,
        data,
        item,
        icon,
        active_data,
        active_property,
        *,
        index = 0,
        flt_flag = 0,
    ):
        # 你可以在这里自定义每个列表项的显示方式
        layout.prop(item, "name", text="", emboss=False, icon_value=icon)


class PhotoDriverFace(bpy.types.Panel):
    bl_label = "图片面部控制器"
    bl_idname = "VIEW3D_PT_PHOTO_DRIVER"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "PhotoDriver-Face"

    def draw(self, context):
        pass


class BasicPanel(PhotoDriverFace):
    bl_label = "驱动器绑定管理"
    bl_idname = "VIEW3D_PT_PHOTO_DRIVER_BASE"
    bl_parent_id = 'VIEW3D_PT_PHOTO_DRIVER'

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        row = layout.row()
        row.prop(context.scene, "rig_driver_bool")
        row.prop(context.scene, "photo_all_bool")

        rig_driver_bool = scene.rig_driver_bool

        if rig_driver_bool:
            layout.prop(scene, "control_armature")

            control_armature = context.scene.control_armature
            control_armature: bpy.types.Object

            if control_armature is not None and control_armature.type == 'ARMATURE':
                self._bone_search(layout, scene, control_armature)
        else:
            layout.prop(context.scene, "face_collection")

        column1 = layout.column_flow(columns=2)
        column1.prop(scene, "photo_all_collection")
        column1.prop(scene, "control_collection")
        layout.operator(AddDriver.bl_idname, text='添加驱动器', icon='DRIVER_TRANSFORM')
        layout.operator(RemoveDriver.bl_idname, text='删除驱动器', icon='TRASH')
        layout.label(text='原理: 图片与形态键同名绑定', icon='FILE_3D')

    def _bone_search(self, layout: bpy.types.UILayout, scene: bpy.types.Scene, armature_ob: bpy.types.Object) -> None:
        """Search within the bones of the given armature."""
        assert armature_ob and armature_ob.type == 'ARMATURE'

        layout.prop_search(
            scene,
            "control_bone_name",
            armature_ob.data,
            "edit_bones" if armature_ob.mode == 'EDIT' else "bones",
        )


class AdvancedPanel(PhotoDriverFace):
    bl_label = "预设管理"
    bl_idname = "VIEW3D_PT_PHOTO_DRIVER_ADVANCED"
    bl_parent_id = 'VIEW3D_PT_PHOTO_DRIVER'

    def draw(self, context):
        layout = self.layout
        scene = context.scene


        row = layout.row()
        row.template_list("FILE_UL_List", "", scene, "file_list", scene, "file_list_index")

        col = row.column(align=True)

        col.operator(AddFolders.bl_idname, icon='ADD')
        col.operator(FileDelete.bl_idname, icon="TRASH")
        col.operator(OpenFiles.bl_idname, icon="LOOP_FORWARDS")
        col.operator(ReturnFolders.bl_idname, icon="LOOP_BACK")

        layout.prop(scene, "select_preset")
        layout.operator(ImportPhoto.bl_idname, text='导入图片', icon='IMPORT')
        # layout.prop(scene, "preset_name")
        # layout.operator(FileUpdate.bl_idname, text= "刷新", icon= "FILE_REFRESH")

        layout.prop(scene, "select_type")
        column2 = layout.column_flow(columns=2)
        column2.prop(scene, "first_name")
        column2.prop(scene, "last_name")

        layout.operator(PhotoTaken.bl_idname, text="拍摄图片(增加预设)", icon="OUTLINER_OB_CAMERA")

        layout.prop(scene, "wide", emboss=True,icon='ALIGN_JUSTIFY')
        layout.operator(AdjustPosition.bl_idname, text="确定图片宽度", icon="ALIGN_JUSTIFY")
        layout.operator(PhotoIdentify.bl_idname, icon="DECORATE_LOCKED")


class OtherPanel(PhotoDriverFace):
    bl_label = "其他管理"
    bl_idname = "VIEW3D_PT_PHOTO_DRIVER_OtherPanel"
    bl_parent_id = 'VIEW3D_PT_PHOTO_DRIVER'

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        layout.label(text="控制器约束管理",icon='TRIA_DOWN')
        box1 = layout.box()
        co = box1.column_flow(columns=3)
        co.prop(context.scene, "brow_constraints_value")
        co.prop(context.scene, "eyes_constraints_value")
        co.prop(context.scene, "mouth_constraints_value")
        box1.operator(AddConstraints.bl_idname, text='添加位置约束', icon='CON_LOCLIMIT')

        layout.separator()

        layout.label(text="控制器约束管理",icon='TRIA_DOWN')
        layout.prop(scene, "control_step")

        layout.separator()

        layout.label(text="当前摄像机差数",icon='TRIA_DOWN')

        try:
            cam = bpy.data.cameras[context.scene.camera.name]
            cam : bpy.types.Camera

            box2 = layout.box()
            box2.prop(cam, "type")

            col = box2.column()
            col.separator()
            if cam.type == 'PERSP':
                if cam.lens_unit == 'MILLIMETERS':
                    col.prop(cam, "lens")
                elif cam.lens_unit == 'FOV':
                    col.prop(cam, "angle")
                col.prop(cam, "lens_unit")

            elif cam.type == 'ORTHO':
                col.prop(cam, "ortho_scale")
        except AttributeError:
            layout.label(text="没有摄像机", icon='ERROR')

        layout.separator()

        layout.label(text="当前输出差数", icon='TRIA_DOWN')

        rd = scene.render

        box3 = layout.box()

        if rd.has_multiple_engines:
            layout.prop(rd, "engine", text="Render Engine")

        col = box3.column(align=True)
        col.prop(rd, "resolution_x", text="Resolution X")
        col.prop(rd, "resolution_y", text="Y")
        col.prop(rd, "resolution_percentage", text="%")

        col = box3.column(align=True)
        col.prop(rd, "pixel_aspect_x", text="Aspect X")
        col.prop(rd, "pixel_aspect_y", text="Y")

        col = box3.column(align=True)
        col.prop(rd, "use_border")
        sub = col.column(align=True)
        sub.active = rd.use_border
        sub.prop(rd, "use_crop_to_border")


def _load_folders(context):
    global file_path
    file_list = context.scene.file_list
    if os.path.isfile(file_path):
        return
    file_list.clear()
    for folder_name in os.listdir(file_path):
        # folder_path = os.path.join(file_path, folder_name)
        # if os.path.isdir(folder_path):
        item = file_list.add()
        item.name = folder_name


def _find_preset_root_bool(context):
    global file_path
    file_list = context.scene.file_list
    index = context.scene.file_list_index

    try:
        data_path = f"{file_list[index].name}"
    except IndexError:
        return False

    local_path = os.path.join(file_path, data_path)

    try:
        for entry in os.listdir(local_path):
            entry_path = os.path.join(local_path, entry)
            if os.path.isfile(entry_path) and entry == "_preset_root_.txt":
                return True
            else:
                continue
        return False
    except NotADirectoryError:
        return False


class LoadFolders(bpy.types.Operator):
    bl_idname = "file_list.load_folders_photo"
    bl_label = "Load Folders from Directory"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):

        context.scene.file_list.clear()

        global file_path
        file_path = PHOTO_PRESET_FILE

        _load_folders(context)

        return {'FINISHED'}


class OpenFiles(bpy.types.Operator):
    bl_idname = "file_list.open_files_photo"
    bl_label = ''
    bl_description = "打开文件"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        file_list = scene.file_list
        file_list_index = scene.file_list_index
        global file_path

        try:
            data_path = f"{file_list[file_list_index].name}"
        except IndexError:
            self.report({'ERROR'},"要选择预设")
            return {'FINISHED'}
        # for folder_name in os.listdir(file_path):
        #     folder_path = os.path.join(file_path, folder_name)
        #     if os.path.isdir(folder_path):
        if file_path == PHOTO_PRESET_FILE:
            local_path = os.path.join(PHOTO_PRESET_FILE,data_path)
        else:
            local_path = os.path.join(file_path,data_path)

        if os.path.isdir(local_path):
            file_path = local_path
        elif os.path.isfile(local_path):
            self.report({'INFO'},"请选择文件夹而非文件")
            return {'FINISHED'}

        _load_folders(context)

        return {'FINISHED'}


class ReturnFolders(bpy.types.Operator):
    bl_idname = "file_list.return_folders_photo"
    bl_label = ""
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = "返回上级文件"

    def execute(self, context):
        global file_path

        if PHOTO_PRESET_FILE == os.path.dirname(file_path):
            file_path = PHOTO_PRESET_FILE

        elif file_path == PHOTO_PRESET_FILE:
            pass

        else:
            file_path = os.path.dirname(file_path)

        _load_folders(context)

        return {'FINISHED'}


class AddFolders(bpy.types.Operator):
    bl_idname = "file_list.add_folders_photo"
    bl_label = ""
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = "添加文件"

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        layout = self.layout

        layout.prop(context.scene, "file_type")
        layout.prop(context.scene,"preset_name")

    def execute(self, context):
        scene = context.scene
        global  file_path
        preset_name = scene.preset_name
        select_type = ["brow", "eyes", "mouth"]

        full_path = os.path.join(file_path, preset_name)

        # 检查文件夹是否已经存在
        if not os.path.exists(full_path):
            # 创建文件夹
            if scene.file_type:
                os.makedirs(full_path)
            else:
                for _type in select_type:
                    _full_path = os.path.join(full_path,_type)
                    os.makedirs(_full_path)

                with open(os.path.join(full_path,"_preset_root_.txt"), "w", encoding='utf-8') as root_file:
                    root_file.write("用于查找预设位置,别删")


            self.report({"INFO"},f"文件夹 '{preset_name}' 创建成功！")
        else:
            self.report({"INFO"},f"文件夹 '{preset_name}' 已经存在。")

        _load_folders(context)

        return {'FINISHED'}


class FileDelete(bpy.types.Operator):
    bl_label = ''
    bl_idname = "scene.photo_delete"
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = '删除选中预设，无法撤回'

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        file_list = context.scene.file_list
        index = context.scene.file_list_index
        try:
            folders_name = file_list[index].name
        except IndexError:
            self.report({'ERROR'}, f"没有预设可删除")
            return {"FINISHED"}


        # select_preset = f"{PHOTO_PRESET_FILE}\\{folders_name}"
        select_preset = os.path.join(file_path,folders_name)
        if os.path.isfile(select_preset) :
            if folders_name ==  "_preset_root_.txt":
                self.report({'INFO'},"用于查找预设位置,不能删,要删就要删所在目录")
                return {'FINISHED'}
            self.report({'INFO'}, "要删就要删所在目录")
            return {'FINISHED'}
        else:
            shutil.rmtree(select_preset)

        _load_folders(context)

        self.report({"INFO"}, "成功删除预设")
        return {'FINISHED'}


class PhotoTaken(bpy.types.Operator):
    bl_label = '拍摄图片'
    bl_idname = 'scene.import_photo_driver'
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = '形成图片,要点击对应的预设名,对形态键相同的物体集合'

    @classmethod
    def poll(cls, context: bpy.types.Context):
        if context.scene.face_collection is not None:
            return _find_preset_root_bool(context)

    def execute(self, context):

        scene = context.scene

        select_type = scene.select_type
        file_list = scene.file_list
        index = scene.file_list_index
        try:
            folders_name = file_list[index].name
        except IndexError:
            self.report({'ERROR'}, f"没有选择预设")
            return {"FINISHED"}

        first_name = scene.first_name
        last_name = scene.last_name

        sk_name = {}
        face_collection = list(scene.face_collection.objects)

        for face in face_collection:
            face : bpy.types.Object
            for sk_n in range(len(list(face.data.shape_keys.key_blocks))):
                sk = list(face.data.shape_keys.key_blocks)[sk_n]
                sk_name[sk.name] = sk_n
                # key : name , value : index

        if last_name not in sk_name.keys():
            self.report({"ERROR"}, f'没有名为"{last_name}"的形态键')
            return {'FINISHED'}
        if first_name not in sk_name.keys():
            self.report({"ERROR"}, f'没有名为"{first_name}"的形态键')
            return {'FINISHED'}

        def update_progress_bar(iteration, total):
            progress = iteration / total
            bpy.context.window_manager.progress_begin(0, 100)  # 开始进度条
            bpy.context.window_manager.progress_update(int(progress * 100))  # 更新
            if iteration == total:
                bpy.context.window_manager.progress_end()  # 结束进度条
                self.report({"INFO"}, "拍摄成功")
            bpy.context.window_manager.progress_update(progress)  # 更新界面

        last = sk_name[last_name] + 1
        first = sk_name[first_name]

        def save_render(save_name):
            bpy.ops.render.render(use_viewport=True)
            # 保存渲染结果
            save_path = os.path.join(file_path, folders_name, select_type, f"{save_name}.png")
            # save_path = os.path.join(PHOTO_PRESET_FILE,f"{preset_name}",f"{sk_col[n].name}.png")
            bpy.data.images["Render Result"].save_render(save_path)
            # PHOTO_PRESET_FILE + f"\\{preset_name}" + f"\\{sk_col[n].name}.png")
            update_progress_bar(amount, last - first)

        def sk_to_0(ob : bpy.types.Object):
            ob_col = list(ob.data.shape_keys.key_blocks)
            for sa_k in ob_col:
                sa_k.value = 0

        for face in face_collection:
            face: bpy.types.Object
            sk_to_0(face)
        amount = 0
        save_render(f"1初始{select_type}1")

        s_name = "ERROR"
        for i in range(first,last):
            for face in face_collection:
                face : bpy.types.Object
                sk_to_0(face)
                s_k = list(face.data.shape_keys.key_blocks)[i]
                s_k.value = 1
                s_name = s_k.name
            amount += 1
            save_render(s_name)

        for face in face_collection:
            face: bpy.types.Object
            sk_to_0(face)

        _load_folders(context)

        return {'FINISHED'}


class ImportPhoto(bpy.types.Operator):
    bl_label = '导入所选类型图片'
    bl_idname = 'scene.import_photo'
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = "要点击场景集合"

    @classmethod
    def poll(cls, context):
        return _find_preset_root_bool(context)

    def execute(self, context):

        _load_folders(context)
        # if not os.path.exists(FACE_BLEND_FILE):
        #     self.report({'ERROR'}, f"文件 {FACE_BLEND_FILE} 不存在！")
        #     return {'CANCELLED'}
        #
        # append_path = os.path.join(FACE_BLEND_FILE, "Collection", "FaceControl")
        #
        #
        # 文件导入

        select_type = ["brow","eyes","mouth","other"]
        # brow eyes mouth
        file_list = context.scene.file_list
        list_index = context.scene.file_list_index
        folders_name = file_list[list_index].name
        # select_preset = f"{PHOTO_PRESET_FILE}\\{folders_name}"
        # filepath_root_name


        def image_import(image_name, filepath):
            bpy.ops.image.import_as_mesh_planes(
                relative=False,
                filepath=filepath + f"\\{image_name}",
                files=[{"name": image_name}],
                directory=filepath + "\\",
                align_axis='-Y'
            )
            bpy.data.images[image_name].colorspace_settings.name = 'Filmic sRGB'
            type_collection.append(bpy.data.objects[Path(image_name).stem])

        def create_new_collection_in_active_layer(new_collection_name):
            # 获取当前视图层
            active_layer_collection = bpy.context.view_layer.active_layer_collection

            # 创建新集合
            new_collection = bpy.data.collections.new(new_collection_name)

            # 将新集合添加到当前视图层
            active_layer_collection.collection.children.link(new_collection)
            for layer_collection in bpy.context.view_layer.layer_collection.children:
                if layer_collection.collection == new_collection:
                    bpy.context.view_layer.active_layer_collection = layer_collection
                    break

        def find_collection_index(father_collection,find_name:str):
            collection_name = find_name
            collection_index = -1  # 初始化为-1，表示未找到

            for index_find, collection_find in enumerate(father_collection):
                if collection_find.name == collection_name:
                    collection_index = index_find
                    break
            return collection_index

        create_new_collection_in_active_layer("photo_all_collection")
        base_index = find_collection_index(
            context.scene.collection.children,"photo_all_collection") + 1


        for name in select_type:
            type_collection = []
            # 调用函数，创建新集合
            create_new_collection_in_active_layer(name)

            #导入图片
            data_path = os.path.join(file_path,folders_name,name)
            # data_path = os.path.join(select_preset, name)
            for root1, dirs1, files1 in os.walk(data_path):
                for image in files1:
                    image_import(image, root1)

            for photo in type_collection:
                photo.select_set(True)
            index = base_index + find_collection_index(
                bpy.data.collections["photo_all_collection"].children,name) + 1
            bpy.ops.object.move_to_collection(collection_index=index)
            for photo in type_collection:
                photo.select_set(False)


        self.report({"INFO"}, "成功导入")
        return {'FINISHED'}


class AdjustPosition(bpy.types.Operator):
    bl_label = '确定图片宽度'
    bl_idname = 'scene.photo_position_adjust'
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = f"调整选择类型宽度"

    @classmethod
    def poll(cls, context):
        return _find_preset_root_bool(context)

    def execute(self, context):

        # bpy.ops.file_list.load_folders_photo()
        _load_folders(context)

        # file_list = context.scene.file_list
        # index = context.scene.file_list_index
        # try:
        #     folders_name = file_list[index].name
        # except IndexError:
        #     self.report({'ERROR'},"请选择对应预设")
        #     return {'FINISHED'}
        # brow eyes mouth
        select_type = context.scene.select_type
        # # filepath_root_name
        # file_list = context.scene.file_list
        # index = context.scene.file_list_index
        # try:
        #     folders_name = file_list[index].name
        # except IndexError:
        #     self.report({'ERROR'}, f"没有预设")
        #     return {"FINISHED"}
        # select_preset = f"{PHOTO_PRESET_FILE}\\{folders_name}"
        # select_preset = os.path.join(file_path,folders_name)

        wide = context.scene.wide
        wide : float


        try:
            type_collections = list(bpy.data.collections[f"{select_type}"].objects)
        except KeyError:
            self.report({'ERROR'},f"没有名为{select_type}的集合")
            return {"FINISHED"}

        try:
            x = type_collections[0].dimensions[0]
            y = type_collections[0].dimensions[1]
        except IndexError:
            self.report({'ERROR'},"请选择有图片集合对应的模式")
            return {'FINISHED'}

        a = 0 #all
        d = 0 #begain-depth

        #横向数量
        n_x = int(wide / x)
        n_a = len(type_collections)
        # n_a = 0
        # data_file = os.path.join(select_preset,select_type)
        # #总数量
        # for root1, dirs1, files1 in os.walk(data_file):
        #     n_a = len(files1)
        # if n_a == 0:
        #     self.report({"INFO"},f"{select_preset}中没有{select_type}")


        while a < n_a:
            # n_a =29 and n_x = 7
            # >>>n = [0,1,2,...,6]
            for n in range(n_x):
                type_collections[n + n_x*d].location.x = n * x
                type_collections[n + n_x*d].location.z = -d * y
                #all
                a += 1
                if a == n_a:
                    break
            d += 1

        for photo in type_collections:
            photo.select_set(True)

        self.report({"INFO"}, "成功移动")
        return {"FINISHED"}


class PhotoIdentify(bpy.types.Operator):
    bl_label = '确定图片(与控制器)'
    bl_idname = 'object.photo_identify'
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = "不渲染,无阴影,在前面,图片不被选中"

    @classmethod
    def poll(cls, context):
        scene = context.scene
        if scene.photo_all_collection is not None  and  scene.control_collection is not None:
            return True

    def execute(self, context):
        #图片属性
        control_collection = list(context.scene.control_collection.objects)
        photo_all_collection = context.scene.photo_all_collection

        #控制器状态
        for c in control_collection:
            #controler
            c.hide_select = False
            c.hide_render = True   #不渲染
            c.visible_shadow = False    #无阴影
            c.show_in_front = True      #在前面

        #photo
        photo_all_collection.hide_select = True  #不被选中
        for a in list(photo_all_collection.children):
            for b in list(a.objects):
                b : bpy.types.Object
                b.show_wire = True
                b.display_type = "TEXTURED"
                b.hide_render = True  # 不渲染
                b.visible_shadow = False  #无阴影
                b.show_in_front = True  # 在前面
        # bpy.data.objects["light"].hide_select = True
        # bpy.data.objects["light"].hide_render = True
        # add_driver_transforms(bpy.data.lights["LightArea"],'control_position','energy',-1
        #            ,"var","var","SCALE_AVG")
        #灯光强度调节
        return {"FINISHED"}


class AddConstraints(bpy.types.Operator):
    bl_idname = 'object.add_constraints_control'
    bl_label = '添加位置约束'
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = "原理是图片与形态键同名绑定"

    @classmethod
    def poll(cls, context: bpy.types.Context):
        return context.scene.control_collection is not None

    def execute(self, context):

        control_collection = context.scene.control_collection
        brow_n = context.scene.brow_constraints_value
        eyes_n = context.scene.eyes_constraints_value
        mouth_n = context.scene.mouth_constraints_value

        # 添加约束
        def limit_location(objects, max_x, min_z):
            objects.constraints.clear()
            objects.constraints.new(type="LIMIT_LOCATION")

            objects.constraints[0].use_min_x = True
            objects.constraints[0].use_min_y = True
            objects.constraints[0].use_min_z = True
            objects.constraints[0].use_max_x = True
            objects.constraints[0].use_max_y = True
            objects.constraints[0].use_max_z = True

            objects.constraints[0].owner_space = 'LOCAL'

            objects.constraints[0].min_x = 0
            objects.constraints[0].min_y = 0
            objects.constraints[0].min_z = min_z
            objects.constraints[0].max_x = max_x
            objects.constraints[0].max_y = 0
            objects.constraints[0].max_z = 0

        for con in list(control_collection.objects):
            # 限定位置
            if "control_brow" in con.name:
                limit_location(con, brow_n[0], brow_n[1])
            if 'control_eyes' in con.name:
                limit_location(con, eyes_n[0], eyes_n[1])
            if "control_mouth" in con.name:
                limit_location(con, mouth_n[0], mouth_n[1])

        return {'FINISHED'}



class RemoveDriver(bpy.types.Operator):
    bl_label = '删除驱动器'
    bl_idname = 'object.remove_driver_face'
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = '要点击 要绑定物体集合'

    @classmethod
    def poll(cls, context: bpy.types.Context):
        scene = context.scene

        if scene.rig_driver_bool:
            if scene.control_armature:
                if scene.control_armature.type != 'ARMATURE':
                    return scene.control_armature is not None
                else:
                    return scene.control_bone_name != ""
            else:
                return False
        else:
            return scene.face_collection is not None

    def execute(self, context: bpy.types.Context):
        scene = context.scene

        if scene.rig_driver_bool:

            control_bone_name = scene.control_bone_name
            control_bone_name: str

            control_armature = scene.control_armature
            control_armature: bpy.types.Object

            control_bone = control_armature.pose.bones[f"{control_bone_name}"]

            if control_armature.animation_data:
                # 检查是否存在驱动器
                for prop_name in list(control_bone.keys()):
                    data_path = f'pose.bones["{control_bone_name}"]["{prop_name}"]'
                    driver = control_armature.animation_data.drivers.find(data_path)
                    if driver:
                        # 删除驱动器
                        control_armature.animation_data.drivers.remove(driver)
        else:
            face_collection = list(scene.face_collection.objects)
            for face in face_collection:
                for key in list(face.data.shape_keys.key_blocks):
                    key.driver_remove('value', -1)
        self.report({'INFO'}, "成功删除驱动器")
        return {'FINISHED'}


class AddDriver(bpy.types.Operator):
    bl_idname = 'object.add_driver_photo'
    bl_label = '添加驱动器'
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = "原理是图片与形态键同名绑定"

    @classmethod
    def poll(cls, context: bpy.types.Context):
        scene = context.scene

        if scene.rig_driver_bool:
            if scene.control_armature:
                if scene.control_armature.type != 'ARMATURE':
                    return scene.control_armature is not None
                else:
                    return scene.control_bone_name != ""
            else:
                return False
        else:
            return scene.face_collection  is not None

    def execute(self, context: bpy.types.Context):

        bpy.ops.object.remove_driver_face()

        scene = context.scene
        control_collection, photo_all_collection = [None, None]
        face_collection = scene.face_collection
        photo_all_collection : bpy.types.Collection
        control_collection: bpy.types.Collection
        face_collection: bpy.types.Collection

        control_bone_name = scene.control_bone_name
        control_bone_name: str

        control_armature = scene.control_armature
        control_armature: bpy.types.Object

        if scene.rig_driver_bool:
            control_bone = control_armature.pose.bones[control_bone_name]
        else:
            control_bone = None
        # face = context.scene.face

        data_collections = []
        for all_col in bpy.data.collections:
            data_collections.append(all_col.name)

        if context.scene.control_collection:
            control_collection = context.scene.control_collection
        elif "control_collection" in data_collections:
            control_collection = bpy.data.collections['control_collection']
        else:
            self.report({'WARNING'}, f"没有控制集合")

        if context.scene.photo_all_collection:
            photo_all_collection = context.scene.photo_all_collection
        elif "photo_all_collection" in data_collections:
            photo_all_collection = bpy.data.collections['photo_all_collection']
        else:
            self.report({'WARNING'}, f"没有图片总集合")

        # face_collection = context.collection
        # self.report({'WARNING'}, f'{photo_all_collection} and \n {control_collection}')
        # return {'CANCELLED'}

        # 添加驱动器的函数
        def add_driver_transforms(driver_object, target_name, var_name, expression, transform_type,path=None, index=None, data_path=None):

            target_object = bpy.data.objects.get(target_name)
            # 获取或创建驱动器

            if data_path:
                fcurve = driver_object.animation_data.drivers.find(data_path)
                if fcurve is None:
                    fcurve = driver_object.animation_data.drivers.new(data_path)
                # 获取驱动器对象
                driver = fcurve.driver
            else:
                driver = driver_object.driver_add(path, index).driver

            driver.type = 'SCRIPTED'

            # 设置表达式
            driver.expression = expression
            driver.use_self = False  # 取消勾选“使用自身”

            # 添加输入变量
            var = driver.variables.new()
            var.name = var_name  # 变量名称
            var.type = 'TRANSFORMS'  # 变量类型设置为“变换通道”
            var.targets[0].id = target_object  # 目标物体
            var.targets[0].transform_type = transform_type  # 变换通道类型
            var.targets[0].transform_space = 'TRANSFORM_SPACE'  # 空间类型

        def add_driver_distance(driver_object, target_object1, target_object2, var_name, expression, path=None, index=None,data_path=None):

            if data_path:
                fcurve = driver_object.animation_data.drivers.find(data_path)
                if fcurve is None:
                    fcurve = driver_object.animation_data.drivers.new(data_path)
                driver = fcurve.driver
            else:
                driver = driver_object.driver_add(path, index).driver

            driver.type = 'SCRIPTED'

            # 设置表达式
            driver.expression = expression
            driver.use_self = False  # 取消勾选“使用自身”

            # 添加输入变量
            var = driver.variables.new()
            var.name = var_name  # 变量名称
            var.type = 'LOC_DIFF'

            var.targets[0].id = target_object1  # 目标物体
            var.targets[1].id = target_object2
            var.targets[0].transform_space = 'TRANSFORM_SPACE'  # 空间类型
            var.targets[1].transform_space = 'TRANSFORM_SPACE'  # 空间类型

            # 驱动控制器移动

        for control_position in list(control_collection.objects):
            add_driver_transforms(control_position, control_position.name, 'self_loc', 'round(self_loc)',
                                  'LOC_X', path= 'location', index=0)
            add_driver_transforms(control_position, control_position.name, 'self_loc', 'round(self_loc)',
                                  'LOC_Z', path='location', index= 2)

        # 外部变量var.shape_key_add_driver()储存
        brow = 0
        other = 0
        eyes = 0
        mouth = 0
        # 判断变量对应集合正确
        for control in list(control_collection.objects):
            # 判断变量对应集合正确
            if "brow" in control.name:
                brow += 1
            if "eyes" in control.name:
                eyes += 1
            if "mouth" in control.name:
                mouth += 1
            if "other" in control.name:
                other += 1

        # 同名绑定形态键g
        def shape_key_add_driver(times : int,driver_ob : bpy.data.shape_keys,data_path=None):
            """
            :param times : control's amount
            :param driver_ob : bpy.types.Object
            :param data_path : the Data Pah (!= Full Data Path)
            """
            control_step = scene.control_step
            # remove_driver(shape_key,"value",-1)
            # 允许多物体的表达式
            expression_key = ""
            for num in range(times):
                # 确认表达式
                loc = "var" + '_00' + str(num)
                sca = "scale" + '_00' + str(num)

                if num == 0:
                    expression_key = f"scale*(1-round(var)/{control_step})"
                else:
                    if num == 1:
                        local_var = "var"
                    else:
                        local_var = "var" + '_00' + str(num - 1)
                    expression_key += f" if {local_var} <= 1 else {sca}*(1-round({loc})/{control_step})"
            # 确保不重复添加

            # 添加驱动器
            if scene.rig_driver_bool:
                add_driver_transforms(driver_ob,control.name,"scale",
                                            expression_key, 'SCALE_AVG',data_path=data_path)
                add_driver_distance(driver_ob, photo, control,
                                "var", expression_key,data_path=data_path)
            else:
                add_driver_transforms(driver_ob, control.name, "scale",
                                            expression_key, 'SCALE_AVG',path='value',index= -1)
                add_driver_distance(driver_ob, photo, control,
                                        "var", expression_key, path='value',index= -1)


        def photo_to_var(name) -> int:
            if "brow" in name:
                return brow
            if "eyes" in name:
                return eyes
            if "mouth" in name:
                return mouth
            if "other" in name:
                return other

        # 删除驱动器
        try:
            for obj in list(face_collection.objects):
                for key in list(obj.data.shape_keys.key_blocks):
                    key.driver_remove('value', -1)
        except AttributeError:
            self.report({'WARNING'}, "物体没有形态键")
            return {'FINISHED'}

        # face_name = ["mouth","eyes",'brow']
        # 获取control

        def _add_driver_collection(amount: int):
            if scene.rig_driver_bool:
                if control_armature.type == 'ARMATURE':
                    for prop_name in list(control_bone.keys()):
                        # 同名判断
                        if prop_name == photo.name:
                            prop_data_path = f'pose.bones["{control_bone_name}"]["{prop_name}"]'
                            shape_key_add_driver(amount, control_armature, prop_data_path)
            else:
                for face in list(face_collection.objects):
                    # 获取绑定face物体的形态键collection
                    for shape_key in list(face.data.shape_keys.key_blocks):
                        # 同名判断
                        if shape_key.name == photo.name:
                            shape_key_add_driver(amount, shape_key)


        for control in list(control_collection.objects):
            # 获取绑定物体总collection
            if scene.photo_all_bool:
                for photo_collection in list(photo_all_collection.children):
                # 判断driver is True
                    if photo_collection.name in control.name:
                        # 获取绑定物体
                        for photo in photo_collection.objects:
                            #获取绑定face物体
                            _add_driver_collection(photo_to_var(photo_collection.name))
            else:
                for photo in photo_all_collection.objects:
                    _add_driver_collection(len(list(control_collection.objects)))

        if scene.rig_driver_bool:
            bpy.ops.object.add_driver_rig()

        self.report({'INFO'}, "绑定成功")
        return {'FINISHED'}


